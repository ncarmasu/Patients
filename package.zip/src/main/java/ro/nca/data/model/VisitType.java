package ro.nca.data.model;

/**
 * Created by Ioana on 9/10/2017.
 */
public enum VisitType {

    CONSULTATION,
    HOSPITALIZATION
}
